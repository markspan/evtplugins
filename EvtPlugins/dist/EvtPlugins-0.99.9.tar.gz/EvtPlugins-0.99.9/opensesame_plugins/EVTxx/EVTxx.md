# EVT2 Marker plugin

Copyright 2010-2016 Mark Span (<m.m.span@rug.nl>)


[opensesame]: http://www.cogsci.nl/opensesame
[evt2_home]: https://github.com/markspan/EVT2

