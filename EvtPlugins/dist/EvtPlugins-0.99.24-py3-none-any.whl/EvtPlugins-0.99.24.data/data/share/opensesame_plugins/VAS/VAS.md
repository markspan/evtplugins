# Auto_example

You can define your help files in [Markdown syntax](http://daringfireball.net/projects/markdown/syntax).