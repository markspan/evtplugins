# RUG Responsbox plugin

Copyright 2019-2021 Eise Hoekstra (<Eize.Hoekstra@rug.nl>)

When this plugin is inserted in the timeline or selected, it will present itself like this :

The label may be changed the same way as it is done with all plugins in Opensesame.




[opensesame]: http://www.cogsci.nl/opensesame
[EVT/RSP_home]: https://github.com/markspan/EventExchanger
